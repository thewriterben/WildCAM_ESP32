#!/usr/bin/env python3
"""
Create ESP32 Wildlife Camera Complete Package
Generates a zip file with the entire ecosystem
"""

import os
import zipfile
from datetime import datetime
import json

def create_wildlife_cam_package():
    """Create a complete ESP32 Wildlife Camera package"""
    
    # Create base directory structure
    base_dir = "ESP32WildlifeCAM_Complete"
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    zip_filename = f"ESP32WildlifeCAM_Complete_{timestamp}.zip"
    
    # File contents dictionary
    files = {}
    
    # ==================== README.md ====================
    files['README.md'] = '''# ESP32 Wildlife Camera - Professional Wildlife Monitoring System

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Platform](https://img.shields.io/badge/Platform-ESP32-blue)](https://www.espressif.com/en/products/socs/esp32)
[![TensorFlow](https://img.shields.io/badge/TensorFlow-Lite-orange)](https://www.tensorflow.org/lite)

A comprehensive, AI-powered wildlife monitoring ecosystem built on ESP32 with machine learning capabilities, cloud integration, and professional-grade features for conservation research.

## 🌟 Features

### Core Capabilities
- **AI-Powered Detection**: On-device wildlife species identification using TensorFlow Lite
- **Multi-Sensor Support**: PIR, thermal, acoustic, and environmental sensors
- **Smart Triggering**: Motion, thermal, sound, and AI-predictive triggers
- **Cloud Integration**: Automatic upload to cloud platforms (AWS, Google Wildlife Insights)
- **Power Optimization**: Solar charging support with intelligent power management
- **Remote Configuration**: Web-based and mobile app configuration
- **Edge Computing**: Process data locally to minimize transmission needs

### Advanced Features
- **Species Classification**: Identify 20+ common wildlife species
- **Individual Tracking**: Track individual animals across multiple captures
- **Behavioral Analysis**: Detect and classify animal behaviors
- **Multi-Camera Networks**: Mesh networking for camera arrays
- **Real-time Alerts**: Instant notifications for rare species or events
- **Data Analytics**: Comprehensive biodiversity metrics and reports

## 🚀 Quick Start

See [docs/SETUP_GUIDE.md](docs/SETUP_GUIDE.md) for detailed instructions.

## 📚 Documentation

- [Hardware Assembly Guide](docs/HARDWARE_ASSEMBLY.md)
- [API Documentation](docs/API_DOCUMENTATION.md)
- [Model Training Guide](docs/MODEL_TRAINING.md)
- [Deployment Guide](docs/DEPLOYMENT.md)

## 📄 License

MIT License - see [LICENSE](LICENSE) file for details
'''

    # ==================== platformio.ini ====================
    files['firmware/platformio.ini'] = '''[env:esp32cam]
platform = espressif32
board = esp32cam
framework = arduino
monitor_speed = 115200
upload_speed = 921600

lib_deps = 
    espressif/esp32-camera @ ^2.0.0
    bblanchon/ArduinoJson @ ^6.21.2
    sandeepmistry/LoRa @ ^0.8.0
    adafruit/Adafruit MLX90640 @ ^1.0.2
    paulstoffregen/Time @ ^1.6.1
    knolleary/PubSubClient @ ^2.8
    me-no-dev/AsyncTCP @ ^1.1.1
    me-no-dev/ESP Async WebServer @ ^1.2.3

build_flags = 
    -DCORE_DEBUG_LEVEL=2
    -DBOARD_HAS_PSRAM
    -mfix-esp32-psram-cache-issue
    -Os

board_build.partitions = partitions.csv
'''

    # ==================== Main Firmware ====================
    files['firmware/src/main.cpp'] = '''/**
 * ESP32 Wildlife Camera - Main Application
 * Professional wildlife monitoring system with AI capabilities
 */

#include <Arduino.h>
#include <WiFi.h>
#include <esp_camera.h>
#include <SD_MMC.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <time.h>
#include "config.h"
#include "camera_config.h"

// System State
enum SystemState {
    STATE_IDLE,
    STATE_MOTION_DETECTED,
    STATE_CAPTURING,
    STATE_PROCESSING,
    STATE_UPLOADING,
    STATE_ERROR
};

SystemState currentState = STATE_IDLE;

// Global variables
unsigned long lastCapture = 0;
const unsigned long CAPTURE_INTERVAL = 30000; // 30 seconds
int pirPin = 13;
float batteryVoltage = 0;

// Function declarations
void setupCamera();
void setupSDCard();
void setupWiFi();
void captureImage();
bool detectMotion();
void uploadToCloud(String filename);
float readBatteryVoltage();
String getTimestamp();

void setup() {
    Serial.begin(115200);
    Serial.println("\\nESP32 Wildlife Camera Starting...");
    
    // Initialize hardware
    pinMode(pirPin, INPUT);
    
    // Setup components
    setupSDCard();
    setupCamera();
    setupWiFi();
    
    // Sync time
    configTime(0, 0, "pool.ntp.org");
    
    Serial.println("System ready!");
}

void loop() {
    // Check motion sensor
    if (detectMotion()) {
        currentState = STATE_MOTION_DETECTED;
        Serial.println("Motion detected!");
        captureImage();
    }
    
    // Periodic capture
    if (millis() - lastCapture > CAPTURE_INTERVAL) {
        captureImage();
        lastCapture = millis();
    }
    
    // Monitor battery
    batteryVoltage = readBatteryVoltage();
    if (batteryVoltage < 3.3) {
        Serial.println("Low battery - entering sleep mode");
        esp_deep_sleep_start();
    }
    
    delay(100);
}

void setupCamera() {
    camera_config_t config;
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = Y2_GPIO_NUM;
    config.pin_d1 = Y3_GPIO_NUM;
    config.pin_d2 = Y4_GPIO_NUM;
    config.pin_d3 = Y5_GPIO_NUM;
    config.pin_d4 = Y6_GPIO_NUM;
    config.pin_d5 = Y7_GPIO_NUM;
    config.pin_d6 = Y8_GPIO_NUM;
    config.pin_d7 = Y9_GPIO_NUM;
    config.pin_xclk = XCLK_GPIO_NUM;
    config.pin_pclk = PCLK_GPIO_NUM;
    config.pin_vsync = VSYNC_GPIO_NUM;
    config.pin_href = HREF_GPIO_NUM;
    config.pin_sscb_sda = SIOD_GPIO_NUM;
    config.pin_sscb_scl = SIOC_GPIO_NUM;
    config.pin_pwdn = PWDN_GPIO_NUM;
    config.pin_reset = RESET_GPIO_NUM;
    config.xclk_freq_hz = 20000000;
    config.pixel_format = PIXFORMAT_JPEG;
    config.frame_size = FRAMESIZE_UXGA;
    config.jpeg_quality = 10;
    config.fb_count = 2;
    
    esp_err_t err = esp_camera_init(&config);
    if (err != ESP_OK) {
        Serial.printf("Camera init failed with error 0x%x\\n", err);
        return;
    }
    
    Serial.println("Camera initialized successfully");
}

void setupSDCard() {
    if (!SD_MMC.begin("/sdcard", true)) {
        Serial.println("SD Card Mount Failed");
        return;
    }
    
    uint8_t cardType = SD_MMC.cardType();
    if (cardType == CARD_NONE) {
        Serial.println("No SD card attached");
        return;
    }
    
    Serial.printf("SD Card Size: %lluMB\\n", SD_MMC.cardSize() / (1024 * 1024));
}

void setupWiFi() {
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
    Serial.print("Connecting to WiFi");
    
    int attempts = 0;
    while (WiFi.status() != WL_CONNECTED && attempts < 20) {
        delay(500);
        Serial.print(".");
        attempts++;
    }
    
    if (WiFi.status() == WL_CONNECTED) {
        Serial.println("\\nWiFi connected");
        Serial.print("IP address: ");
        Serial.println(WiFi.localIP());
    } else {
        Serial.println("\\nWiFi connection failed");
    }
}

void captureImage() {
    currentState = STATE_CAPTURING;
    
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        Serial.println("Camera capture failed");
        currentState = STATE_ERROR;
        return;
    }
    
    // Generate filename with timestamp
    String filename = "/capture_" + getTimestamp() + ".jpg";
    
    // Save to SD card
    File file = SD_MMC.open(filename, FILE_WRITE);
    if (!file) {
        Serial.println("Failed to open file for writing");
        esp_camera_fb_return(fb);
        return;
    }
    
    file.write(fb->buf, fb->len);
    file.close();
    
    Serial.println("Image saved: " + filename);
    
    // Upload if WiFi connected
    if (WiFi.status() == WL_CONNECTED) {
        uploadToCloud(filename);
    }
    
    esp_camera_fb_return(fb);
    currentState = STATE_IDLE;
}

bool detectMotion() {
    return digitalRead(pirPin) == HIGH;
}

void uploadToCloud(String filename) {
    currentState = STATE_UPLOADING;
    
    HTTPClient http;
    http.begin(String(API_ENDPOINT) + "/api/detections");
    http.addHeader("Content-Type", "multipart/form-data");
    
    // Create metadata
    StaticJsonDocument<256> doc;
    doc["device_id"] = WiFi.macAddress();
    doc["timestamp"] = getTimestamp();
    doc["battery"] = batteryVoltage;
    doc["trigger"] = "motion";
    
    String metadata;
    serializeJson(doc, metadata);
    
    // TODO: Implement multipart upload
    
    http.end();
    currentState = STATE_IDLE;
}

float readBatteryVoltage() {
    // Read from ADC pin (voltage divider needed)
    int adcValue = analogRead(34);
    return (adcValue / 4095.0) * 3.3 * 2; // Assuming 2:1 voltage divider
}

String getTimestamp() {
    time_t now;
    time(&now);
    char timestamp[20];
    strftime(timestamp, sizeof(timestamp), "%Y%m%d_%H%M%S", localtime(&now));
    return String(timestamp);
}
'''

    # ==================== Config Header ====================
    files['firmware/src/config.h'] = '''#ifndef CONFIG_H
#define CONFIG_H

// WiFi Configuration - CHANGE THESE!
#define WIFI_SSID "YOUR_WIFI_SSID"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"

// API Configuration
#define API_ENDPOINT "http://your-server.com"
#define API_KEY "your-api-key"

// Hardware Configuration
#define PIR_SENSOR_PIN 13
#define BATTERY_PIN 34
#define LED_FLASH_PIN 4

// Camera Settings
#define CAPTURE_QUALITY 10  // 0-63, lower is better quality
#define CAPTURE_INTERVAL_MS 30000  // 30 seconds

// Power Management
#define LOW_BATTERY_VOLTAGE 3.3
#define CRITICAL_BATTERY_VOLTAGE 3.0
#define DEEP_SLEEP_TIME_SEC 3600  // 1 hour

// Detection Settings
#define MOTION_SENSITIVITY 0.7
#define DETECTION_CONFIDENCE_THRESHOLD 0.75

#endif // CONFIG_H
'''

    # ==================== Camera Config ====================
    files['firmware/src/camera_config.h'] = '''#ifndef CAMERA_CONFIG_H
#define CAMERA_CONFIG_H

// Pin definition for CAMERA_MODEL_AI_THINKER
#define PWDN_GPIO_NUM     32
#define RESET_GPIO_NUM    -1
#define XCLK_GPIO_NUM      0
#define SIOD_GPIO_NUM     26
#define SIOC_GPIO_NUM     27

#define Y9_GPIO_NUM       35
#define Y8_GPIO_NUM       34
#define Y7_GPIO_NUM       39
#define Y6_GPIO_NUM       36
#define Y5_GPIO_NUM       21
#define Y4_GPIO_NUM       19
#define Y3_GPIO_NUM       18
#define Y2_GPIO_NUM        5
#define VSYNC_GPIO_NUM    25
#define HREF_GPIO_NUM     23
#define PCLK_GPIO_NUM     22

#endif // CAMERA_CONFIG_H
'''

    # ==================== Backend App ====================
    files['backend/app.py'] = '''"""
ESP32 Wildlife Camera - Backend API
"""

from flask import Flask, request, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime
import os
import json

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///wildlife.db'
app.config['SECRET_KEY'] = 'your-secret-key-change-this'
app.config['UPLOAD_FOLDER'] = 'uploads'

db = SQLAlchemy(app)
CORS(app)

# Create upload directory
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Database Models
class Camera(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    device_id = db.Column(db.String(50), unique=True, nullable=False)
    name = db.Column(db.String(100))
    location = db.Column(db.JSON)
    last_seen = db.Column(db.DateTime)
    battery_level = db.Column(db.Float)
    
class Detection(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    camera_id = db.Column(db.Integer, db.ForeignKey('camera.id'))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    image_path = db.Column(db.String(500))
    species = db.Column(db.String(100))
    confidence = db.Column(db.Float)
    metadata = db.Column(db.JSON)

# API Routes
@app.route('/api/health', methods=['GET'])
def health_check():
    return jsonify({'status': 'healthy', 'timestamp': datetime.utcnow().isoformat()})

@app.route('/api/cameras', methods=['GET'])
def get_cameras():
    cameras = Camera.query.all()
    return jsonify([{
        'id': c.id,
        'device_id': c.device_id,
        'name': c.name,
        'last_seen': c.last_seen.isoformat() if c.last_seen else None,
        'battery_level': c.battery_level
    } for c in cameras])

@app.route('/api/detections', methods=['POST'])
def upload_detection():
    device_id = request.form.get('device_id')
    
    # Get or create camera
    camera = Camera.query.filter_by(device_id=device_id).first()
    if not camera:
        camera = Camera(device_id=device_id, name=f"Camera {device_id[-6:]}")
        db.session.add(camera)
    
    camera.last_seen = datetime.utcnow()
    camera.battery_level = float(request.form.get('battery', 0))
    
    # Handle image upload
    image = request.files.get('image')
    if image:
        filename = f"{device_id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
        image_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        image.save(image_path)
        
        # Create detection record
        detection = Detection(
            camera_id=camera.id,
            image_path=image_path,
            metadata=json.loads(request.form.get('metadata', '{}'))
        )
        db.session.add(detection)
    
    db.session.commit()
    
    return jsonify({'status': 'success', 'detection_id': detection.id if image else None})

@app.route('/api/detections', methods=['GET'])
def get_detections():
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    
    detections = Detection.query.order_by(Detection.timestamp.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    return jsonify({
        'detections': [{
            'id': d.id,
            'camera_id': d.camera_id,
            'timestamp': d.timestamp.isoformat(),
            'species': d.species,
            'confidence': d.confidence
        } for d in detections.items],
        'total': detections.total,
        'pages': detections.pages
    })

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True, host='0.0.0.0', port=5000)
'''

    # ==================== Requirements ====================
    files['backend/requirements.txt'] = '''Flask==2.3.2
Flask-SQLAlchemy==3.0.5
Flask-CORS==4.0.0
Pillow==10.0.0
numpy==1.24.3
opencv-python==4.8.0.74
tensorflow==2.13.0
boto3==1.28.0
redis==4.6.0
celery==5.3.1
psycopg2-binary==2.9.6
gunicorn==21.2.0
'''

    # ==================== Docker Compose ====================
    files['docker-compose.yml'] = '''version: '3.8'

services:
  backend:
    build: ./backend
    ports:
      - "5000:5000"
    environment:
      - DATABASE_URL=sqlite:///wildlife.db
    volumes:
      - ./backend:/app
      - ./uploads:/app/uploads
    command: python app.py

  frontend:
    build: ./frontend
    ports:
      - "3000:3000"
    environment:
      - REACT_APP_API_URL=http://localhost:5000
    volumes:
      - ./frontend:/app

volumes:
  uploads:
'''

    # ==================== Frontend App ====================
    files['frontend/src/App.js'] = '''import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000';

function App() {
  const [cameras, setCameras] = useState([]);
  const [detections, setDetections] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const [camerasRes, detectionsRes] = await Promise.all([
        axios.get(`${API_URL}/api/cameras`),
        axios.get(`${API_URL}/api/detections`)
      ]);
      
      setCameras(camerasRes.data);
      setDetections(detectionsRes.data.detections);
    } catch (error) {
      console.error('Error fetching data:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="loading">Loading Wildlife Camera System...</div>;
  }

  return (
    <div className="App">
      <header className="App-header">
        <h1>ESP32 Wildlife Camera Dashboard</h1>
      </header>
      
      <main className="dashboard">
        <section className="cameras-section">
          <h2>Active Cameras</h2>
          <div className="camera-grid">
            {cameras.map(camera => (
              <div key={camera.id} className="camera-card">
                <h3>{camera.name}</h3>
                <p>Device: {camera.device_id}</p>
                <p>Battery: {camera.battery_level?.toFixed(1)}V</p>
                <p>Last Seen: {camera.last_seen || 'Never'}</p>
              </div>
            ))}
          </div>
        </section>
        
        <section className="detections-section">
          <h2>Recent Detections</h2>
          <div className="detection-grid">
            {detections.map(detection => (
              <div key={detection.id} className="detection-card">
                <p>Camera: {detection.camera_id}</p>
                <p>{new Date(detection.timestamp).toLocaleString()}</p>
                {detection.species && (
                  <p>Species: {detection.species} ({(detection.confidence * 100).toFixed(1)}%)</p>
                )}
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export default App;
'''

    # ==================== Frontend Package.json ====================
    files['frontend/package.json'] = '''{
  "name": "wildlife-camera-dashboard",
  "version": "1.0.0",
  "private": true,
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "axios": "^1.4.0",
    "react-scripts": "5.0.1"
  },
  "scripts": {
    "start": "react-scripts start",
    "build": "react-scripts build",
    "test": "react-scripts test",
    "eject": "react-scripts eject"
  },
  "eslintConfig": {
    "extends": ["react-app"]
  },
  "browserslist": {
    "production": [">0.2%", "not dead", "not op_mini all"],
    "development": ["last 1 chrome version", "last 1 firefox version", "last 1 safari version"]
  }
}
'''

    # ==================== Frontend CSS ====================
    files['frontend/src/App.css'] = '''.App {
  text-align: center;
  min-height: 100vh;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}

.App-header {
  background-color: rgba(255, 255, 255, 0.95);
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.App-header h1 {
  color: #333;
  margin: 0;
}

.dashboard {
  padding: 20px;
  max-width: 1200px;
  margin: 0 auto;
}

.cameras-section, .detections-section {
  background: white;
  border-radius: 10px;
  padding: 20px;
  margin: 20px 0;
  box-shadow: 0 4px 6px rgba(0,0,0,0.1);
}

.camera-grid, .detection-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 20px;
  margin-top: 20px;
}

.camera-card, .detection-card {
  background: #f8f9fa;
  padding: 15px;
  border-radius: 8px;
  border: 1px solid #dee2e6;
}

.camera-card h3 {
  margin-top: 0;
  color: #495057;
}

.loading {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
  font-size: 24px;
  color: white;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
}
'''

    # ==================== ML Training Script ====================
    files['ml/train_model.py'] = '''"""
Wildlife Detection Model Training Script
"""

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers, models
import numpy as np
import cv2
import os
from sklearn.model_selection import train_test_split

class WildlifeDetector:
    def __init__(self):
        self.model = None
        self.class_names = [
            'deer', 'elk', 'bear', 'wolf', 'fox',
            'rabbit', 'squirrel', 'bird', 'empty'
        ]
        
    def build_model(self, input_shape=(224, 224, 3)):
        """Build CNN model for wildlife detection"""
        self.model = models.Sequential([
            layers.Conv2D(32, (3, 3), activation='relu', input_shape=input_shape),
            layers.MaxPooling2D((2, 2)),
            layers.Conv2D(64, (3, 3), activation='relu'),
            layers.MaxPooling2D((2, 2)),
            layers.Conv2D(128, (3, 3), activation='relu'),
            layers.MaxPooling2D((2, 2)),
            layers.Flatten(),
            layers.Dropout(0.5),
            layers.Dense(128, activation='relu'),
            layers.Dense(len(self.class_names), activation='softmax')
        ])
        
        self.model.compile(
            optimizer='adam',
            loss='sparse_categorical_crossentropy',
            metrics=['accuracy']
        )
        
        return self.model
    
    def train(self, X_train, y_train, X_val, y_val, epochs=50):
        """Train the model"""
        history = self.model.fit(
            X_train, y_train,
            epochs=epochs,
            validation_data=(X_val, y_val),
            batch_size=32,
            callbacks=[
                keras.callbacks.EarlyStopping(patience=5),
                keras.callbacks.ModelCheckpoint(
                    'best_model.h5',
                    save_best_only=True
                )
            ]
        )
        return history
    
    def convert_to_tflite(self, model_path='best_model.h5'):
        """Convert model to TensorFlow Lite for ESP32"""
        model = keras.models.load_model(model_path)
        
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        converter.optimizations = [tf.lite.Optimize.DEFAULT]
        converter.target_spec.supported_types = [tf.float16]
        
        tflite_model = converter.convert()
        
        with open('wildlife_model.tflite', 'wb') as f:
            f.write(tflite_model)
        
        print(f"Model converted to TFLite: {len(tflite_model)} bytes")
        
        # Generate C header file for ESP32
        self.generate_c_header(tflite_model)
    
    def generate_c_header(self, model_bytes):
        """Generate C header file for embedding in ESP32"""
        hex_array = ', '.join([f'0x{b:02x}' for b in model_bytes])
        
        c_code = f"""#ifndef WILDLIFE_MODEL_H
#define WILDLIFE_MODEL_H

const unsigned char wildlife_model[] = {{
    {hex_array}
}};

const unsigned int wildlife_model_len = {len(model_bytes)};

#endif // WILDLIFE_MODEL_H
"""
        
        with open('wildlife_model.h', 'w') as f:
            f.write(c_code)
        
        print("C header file generated: wildlife_model.h")

if __name__ == "__main__":
    # Example usage
    detector = WildlifeDetector()
    model = detector.build_model()
    print(model.summary())
    
    # Convert existing model
    # detector.convert_to_tflite('path/to/your/model.h5')
'''

    # ==================== Setup Script ====================
    files['setup.sh'] = '''#!/bin/bash

echo "======================================"
echo "ESP32 Wildlife Camera Setup"
echo "======================================"

# Check for Python
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is required but not installed."
    exit 1
fi

# Install PlatformIO
echo "Installing PlatformIO..."
pip install platformio

# Install Python dependencies
echo "Installing backend dependencies..."
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cd ..

# Install frontend dependencies
echo "Installing frontend dependencies..."
cd frontend
npm install
cd ..

# Create necessary directories
mkdir -p uploads
mkdir -p models
mkdir -p data

echo ""
echo "Setup complete!"
echo ""
echo "Next steps:"
echo "1. Edit firmware/src/config.h with your WiFi credentials"
echo "2. Connect ESP32-CAM and run: cd firmware && pio run --target upload"
echo "3. Start backend: cd backend && python app.py"
echo "4. Start frontend: cd frontend && npm start"
echo ""
'''

    # ==================== Documentation ====================
    files['docs/SETUP_GUIDE.md'] = '''# ESP32 Wildlife Camera - Setup Guide

## Hardware Requirements

- ESP32-CAM module
- PIR motion sensor (HC-SR501)
- MicroSD card (8GB+)
- 18650 batteries and holder
- USB-to-Serial adapter (for programming)
- Optional: Solar panel (6W+)

## Software Requirements

- PlatformIO or Arduino IDE
- Python 3.8+
- Node.js 14+
- Git

## Step 1: Hardware Assembly

1. Connect PIR sensor to GPIO 13
2. Insert MicroSD card
3. Connect batteries or power supply
4. Connect USB-to-Serial adapter for programming

## Step 2: Firmware Setup

1. Edit `firmware/src/config.h` with your settings:
```cpp
#define WIFI_SSID "your-network"
#define WIFI_PASSWORD "your-password"