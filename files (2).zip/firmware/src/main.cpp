/**
 * ESP32 Wildlife Camera - Main Application
 * Professional wildlife monitoring system with AI capabilities
 * 
 * @author thewriterben
 * @license MIT
 */

#include <Arduino.h>
#include "wildlife_cam.h"
#include "camera_manager.h"
#include "ml_inference.h"
#include "connectivity.h"
#include "power_manager.h"
#include "config.h"

// Global instances
WildlifeCam wildlifeCam;
CameraManager cameraManager;
MLInference mlInference;
ConnectivityManager connectivity;
PowerManager powerManager;

// System state
SystemState currentState = STATE_INITIALIZING;
unsigned long lastHealthCheck = 0;
const unsigned long HEALTH_CHECK_INTERVAL = 30000; // 30 seconds

void setup() {
    Serial.begin(115200);
    Serial.println("\n=================================");
    Serial.println("ESP32 Wildlife Camera v2.0");
    Serial.println("Initializing system...");
    Serial.println("=================================\n");

    // Initialize power management first
    if (!powerManager.begin()) {
        Serial.println("ERROR: Power management initialization failed");
        esp_restart();
    }

    // Check battery level
    float batteryVoltage = powerManager.getBatteryVoltage();
    Serial.printf("Battery voltage: %.2f V\n", batteryVoltage);
    
    if (batteryVoltage < MIN_BATTERY_VOLTAGE) {
        Serial.println("Battery too low! Entering deep sleep...");
        powerManager.enterDeepSleep(LOW_BATTERY_SLEEP_TIME);
    }

    // Initialize SD card for local storage
    if (!SD_MMC.begin("/sdcard", true)) {
        Serial.println("WARNING: SD Card mount failed - continuing without storage");
    } else {
        uint64_t cardSize = SD_MMC.cardSize() / (1024 * 1024);
        Serial.printf("SD Card Size: %lluMB\n", cardSize);
    }

    // Initialize camera
    if (!cameraManager.begin()) {
        Serial.println("ERROR: Camera initialization failed");
        esp_restart();
    }
    Serial.println("Camera initialized successfully");

    // Initialize ML inference engine
    if (!mlInference.begin()) {
        Serial.println("WARNING: ML inference initialization failed");
        Serial.println("Continuing without AI capabilities");
    } else {
        Serial.println("ML model loaded successfully");
    }

    // Initialize connectivity
    connectivity.begin();
    
    if (connectivity.connectWiFi(WIFI_SSID, WIFI_PASSWORD)) {
        Serial.println("WiFi connected");
        Serial.print("IP address: ");
        Serial.println(WiFi.localIP());
    } else {
        Serial.println("WiFi connection failed - will retry later");
    }

    // Initialize sensors
    pinMode(PIR_SENSOR_PIN, INPUT);
    pinMode(LED_FLASH_PIN, OUTPUT);
    digitalWrite(LED_FLASH_PIN, LOW);

    // Initialize web server for configuration
    setupWebServer();

    // Sync time if connected
    if (WiFi.status() == WL_CONNECTED) {
        configTime(GMT_OFFSET_SEC, DAYLIGHT_OFFSET_SEC, NTP_SERVER);
        Serial.println("Time synchronized with NTP server");
    }

    // Load configuration from storage
    loadConfiguration();

    // Set initial state
    currentState = STATE_IDLE;
    Serial.println("\nSystem ready!");
    Serial.println("=================================\n");
}

void loop() {
    // Handle different system states
    switch (currentState) {
        case STATE_IDLE:
            handleIdleState();
            break;
            
        case STATE_MOTION_DETECTED:
            handleMotionDetected();
            break;
            
        case STATE_CAPTURING:
            handleCapturing();
            break;
            
        case STATE_PROCESSING:
            handleProcessing();
            break;
            
        case STATE_UPLOADING:
            handleUploading();
            break;
            
        case STATE_ERROR:
            handleError();
            break;
            
        default:
            currentState = STATE_IDLE;
    }

    // Periodic health check
    if (millis() - lastHealthCheck > HEALTH_CHECK_INTERVAL) {
        performHealthCheck();
        lastHealthCheck = millis();
    }

    // Handle web server requests
    handleWebRequests();

    // Check for OTA updates
    if (WiFi.status() == WL_CONNECTED) {
        checkForUpdates();
    }

    // Minimal delay to prevent watchdog
    delay(10);
}

void handleIdleState() {
    // Check motion sensor
    if (digitalRead(PIR_SENSOR_PIN) == HIGH) {
        Serial.println("Motion detected!");
        currentState = STATE_MOTION_DETECTED;
        return;
    }

    // Check for scheduled capture
    if (shouldCaptureScheduled()) {
        Serial.println("Scheduled capture triggered");
        currentState = STATE_CAPTURING;
        return;
    }

    // Enter light sleep if no activity
    static unsigned long lastActivity = millis();
    if (millis() - lastActivity > IDLE_SLEEP_THRESHOLD) {
        powerManager.enterLightSleep(LIGHT_SLEEP_DURATION);
        lastActivity = millis();
    }
}

void handleMotionDetected() {
    // Debounce motion sensor
    delay(MOTION_DEBOUNCE_MS);
    
    if (digitalRead(PIR_SENSOR_PIN) == HIGH) {
        // Confirmed motion - capture image
        currentState = STATE_CAPTURING;
    } else {
        // False trigger - return to idle
        currentState = STATE_IDLE;
    }
}

void handleCapturing() {
    Serial.println("Capturing image...");
    
    // Capture image
    camera_fb_t* fb = cameraManager.capture();
    
    if (fb == nullptr) {
        Serial.println("Camera capture failed!");
        currentState = STATE_ERROR;
        return;
    }

    // Save raw image temporarily
    String filename = saveImage(fb);
    
    // Create metadata
    JsonDocument metadata;
    metadata["timestamp"] = getTimestamp();
    metadata["trigger"] = "motion";
    metadata["battery"] = powerManager.getBatteryVoltage();
    metadata["temperature"] = readTemperature();
    metadata["humidity"] = readHumidity();
    metadata["filename"] = filename;

    // Process with AI if available
    if (mlInference.isReady()) {
        currentState = STATE_PROCESSING;
        
        // Run inference
        DetectionResult result = mlInference.detectWildlife(fb);
        
        metadata["detection"]["species"] = result.species;
        metadata["detection"]["confidence"] = result.confidence;
        metadata["detection"]["bbox"] = result.boundingBox;
        
        // Log detection
        Serial.printf("Detected: %s (confidence: %.2f)\n", 
                     result.species.c_str(), result.confidence);
        
        // Save annotated image if wildlife detected
        if (result.confidence > DETECTION_THRESHOLD) {
            saveAnnotatedImage(fb, result);
            
            // Trigger alert for rare species
            if (isRareSpecies(result.species)) {
                sendAlert(result, metadata);
            }
        }
    }

    // Return framebuffer
    esp_camera_fb_return(fb);

    // Upload if connected
    if (connectivity.isConnected()) {
        currentState = STATE_UPLOADING;
    } else {
        // Queue for later upload
        queueForUpload(filename, metadata);
        currentState = STATE_IDLE;
    }
}

void handleProcessing() {
    // AI processing is handled in capture state
    // This state can be used for additional processing
    currentState = STATE_IDLE;
}

void handleUploading() {
    Serial.println("Uploading to cloud...");
    
    // Attempt upload
    bool success = uploadToCloud();
    
    if (success) {
        Serial.println("Upload successful");
        
        // Clean up local storage if needed
        if (shouldCleanupStorage()) {
            cleanupOldFiles();
        }
    } else {
        Serial.println("Upload failed - will retry later");
    }

    currentState = STATE_IDLE;
}

void handleError() {
    Serial.println("System error - attempting recovery...");
    
    // Log error
    logError(lastError);
    
    // Attempt recovery
    if (errorCount < MAX_ERROR_RETRY) {
        errorCount++;
        delay(ERROR_RETRY_DELAY);
        currentState = STATE_IDLE;
    } else {
        // Too many errors - restart
        Serial.println("Too many errors - restarting...");
        esp_restart();
    }
}

void performHealthCheck() {
    // Check system health
    float batteryVoltage = powerManager.getBatteryVoltage();
    int freeHeap = ESP.getFreeHeap();
    float cpuTemp = temperatureRead();
    
    // Log telemetry
    Serial.printf("Health: Battery=%.2fV, Heap=%d, CPU=%.1f°C\n", 
                 batteryVoltage, freeHeap, cpuTemp);
    
    // Send telemetry if connected
    if (connectivity.isConnected()) {
        sendTelemetry(batteryVoltage, freeHeap, cpuTemp);
    }
    
    // Check for issues
    if (batteryVoltage < CRITICAL_BATTERY_VOLTAGE) {
        Serial.println("Critical battery! Entering deep sleep...");
        powerManager.enterDeepSleep(CRITICAL_SLEEP_TIME);
    }
    
    if (freeHeap < MIN_FREE_HEAP) {
        Serial.println("Low memory - restarting...");
        esp_restart();
    }
    
    if (cpuTemp > MAX_CPU_TEMP) {
        Serial.println("CPU overheating - entering sleep...");
        powerManager.enterLightSleep(COOLDOWN_TIME);
    }
}