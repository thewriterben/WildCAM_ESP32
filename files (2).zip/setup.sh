#!/bin/bash

# ESP32 Wildlife Camera - Setup Script
# Automated setup for development environment

echo "======================================"
echo "ESP32 Wildlife Camera Setup"
echo "======================================"

# Check for required tools
echo "Checking prerequisites..."

# Check Python
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is required but not installed."
    exit 1
fi

# Check PlatformIO
if ! command -v pio &> /dev/null; then
    echo "Installing PlatformIO..."
    pip install platformio
fi

# Check Docker
if ! command -v docker &> /dev/null; then
    echo "Docker is required for backend deployment."
    echo "Please install Docker from https://docker.com"
fi

# Create directory structure
echo "Creating project directories..."
mkdir -p firmware/{src,include,lib,models}
mkdir -p backend/{api,ml,database}
mkdir -p frontend/src/components
mkdir -p mobile/{android,ios}
mkdir -p hardware/{schematics,pcb,enclosure}
mkdir -p docs
mkdir -p tools/deployment_scripts
mkdir -p data/{images,models,logs}

# Install Python dependencies
echo "Installing Python dependencies..."
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Download pre-trained models
echo "Downloading ML models..."
cd ../models
wget https://github.com/microsoft/CameraTraps/releases/download/v5.0/md_v5a.0.0.pt
echo "MegaDetector v5 downloaded"

# Initialize firmware
echo "Initializing firmware project..."
cd ../firmware
pio init -b esp32cam

# Setup database
echo "Setting up database..."
cd ../backend
docker-compose up -d postgres
sleep 5
python -c "from app import db; db.create_all()"

# Create default configuration
echo "Creating default configuration..."
cat > ../firmware/src/config.h << EOF
#ifndef CONFIG_H
#define CONFIG_H

// WiFi Configuration
#define WIFI_SSID "YOUR_WIFI_SSID"
#define WIFI_PASSWORD "YOUR_WIFI_PASSWORD"

// API Configuration  
#define API_ENDPOINT "http://localhost:5000/api"
#define API_KEY "YOUR_API_KEY"

// Hardware Pins
#define PIR_SENSOR_PIN 13
#define LED_FLASH_PIN 4

// Camera Settings
#define CAMERA_MODEL CAMERA_MODEL_AI_THINKER
#define CAPTURE_INTERVAL 30000  // 30 seconds

// ML Settings
#define USE_EDGE_AI true
#define DETECTION_THRESHOLD 0.7

#endif
EOF

echo ""
echo "======================================"
echo "Setup Complete!"
echo "======================================"
echo ""
echo "Next steps:"
echo "1. Edit firmware/src/config.h with your WiFi credentials"
echo "2. Connect your ESP32-CAM board"
echo "3. Run: cd firmware && pio run --target upload"
echo "4. Start backend: cd backend && docker-compose up"
echo "5. Access dashboard at http://localhost:3000"
echo ""
echo "Documentation: https://github.com/thewriterben/ESP32WildlifeCAM"